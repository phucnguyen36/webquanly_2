import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ArrowRight, Mail, Key, AlertCircle, RefreshCw, CheckCircle2 } from 'lucide-react';
import { 
  authenticateUserAsync, 
  syncUsersRegistryFromCloud, 
  parseUserAccessToken,
  getUsersRegistry,
  saveUsersRegistry,
  UserAccount 
} from '../userRegistry';

interface AuthGateProps {
  onAuthenticated: (user: UserAccount) => void;
}

export default function AuthGate({ onAuthenticated }: AuthGateProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [successNotice, setSuccessNotice] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isUnlocked, setIsUnlocked] = useState(false);

  useEffect(() => {
    // 1. Check for One-Click Access Token in URL (e.g. ?access=... or #access=...)
    try {
      const urlParams = new URLSearchParams(window.location.search);
      let accessToken = urlParams.get('access') || urlParams.get('token');
      
      if (!accessToken && window.location.hash.includes('access=')) {
        const match = window.location.hash.match(/access=([^&]+)/);
        if (match) accessToken = match[1];
      }

      if (accessToken) {
        const tokenUser = parseUserAccessToken(accessToken);
        if (tokenUser && tokenUser.email) {
          // Register / update user in local registry
          const list = getUsersRegistry();
          const existingIdx = list.findIndex(u => u.email.toLowerCase() === tokenUser.email.toLowerCase());
          let updatedList: UserAccount[];
          if (existingIdx >= 0) {
            updatedList = list.map((u, i) => i === existingIdx ? { ...u, ...tokenUser } : u);
          } else {
            updatedList = [tokenUser, ...list];
          }
          saveUsersRegistry(updatedList);

          // Save session
          localStorage.setItem('df_os_active_user', JSON.stringify(tokenUser));
          sessionStorage.setItem('df_os_active_user', JSON.stringify(tokenUser));

          // Clean URL without reloading
          window.history.replaceState({}, document.title, window.location.pathname);

          setSuccessNotice(`Welcome ${tokenUser.name}! Access Verified.`);
          setIsUnlocked(true);
          setTimeout(() => {
            onAuthenticated(tokenUser);
          }, 800);
          return;
        }
      }
    } catch (e) {}

    // 2. If user just clicked "Logout", do not auto-login
    const justLoggedOut = sessionStorage.getItem('df_just_logged_out');
    if (justLoggedOut === 'true') {
      sessionStorage.removeItem('df_just_logged_out');
      syncUsersRegistryFromCloud().catch(() => {});
      return;
    }

    // 3. Check if user session stored in localStorage or sessionStorage
    const savedUser = localStorage.getItem('df_os_active_user') || sessionStorage.getItem('df_os_active_user');
    if (savedUser) {
      try {
        const user = JSON.parse(savedUser) as UserAccount;
        if (user && user.email) {
          onAuthenticated(user);
          return;
        }
      } catch (e) {
        localStorage.removeItem('df_os_active_user');
        sessionStorage.removeItem('df_os_active_user');
      }
    }

    // 4. Pre-fetch cloud users in background
    syncUsersRegistryFromCloud().catch(() => {});
  }, [onAuthenticated]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage('');
    setSuccessNotice('');

    if (!email.trim() || !password.trim()) {
      setErrorMessage('Please enter both Email and Access Password!');
      return;
    }

    setIsLoading(true);
    try {
      const res = await authenticateUserAsync(email, password);
      if (res.success && res.user) {
        setIsUnlocked(true);
        localStorage.setItem('df_os_active_user', JSON.stringify(res.user));
        sessionStorage.setItem('df_os_active_user', JSON.stringify(res.user));
        setTimeout(() => {
          onAuthenticated(res.user!);
        }, 500);
      } else {
        setErrorMessage(res.message || 'Authentication failed. Please verify credentials.');
      }
    } catch (err) {
      setErrorMessage('Authentication error. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AnimatePresence>
      {!isUnlocked && (
        <motion.div
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6 }}
          className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-black text-zinc-100 p-4 md:p-8"
        >
          {/* Subtle ambient radial background glow */}
          <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.18)_0%,rgba(0,0,0,1)_100%)] pointer-events-none" />

          <motion.div
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="w-full max-w-md glass-panel-true p-6 md:p-8 relative z-10 shadow-2xl space-y-6 border border-white/15 rounded-2xl"
          >
            {/* Top Brand Banner */}
            <div className="text-center space-y-2">
              <span className="text-[9px] font-mono tracking-[0.25em] text-zinc-400 uppercase block font-bold">
                DEEP FOCUS SYSTEM INGRESS • v5.0
              </span>
              <h1 className="text-2xl md:text-3xl font-extrabold font-mono uppercase tracking-tight text-white">
                Deep Focus OS
              </h1>
              <p className="text-xs font-sans text-zinc-300">
                Executive Personal Growth & Performance System
              </p>
            </div>

            {/* Success Notice */}
            {successNotice && (
              <div className="p-3 bg-emerald-500/15 border border-emerald-400/40 text-emerald-300 text-xs font-mono flex items-center gap-2 animate-fadeIn rounded-xl">
                <CheckCircle2 className="w-4 h-4 flex-shrink-0 text-emerald-400" />
                <span>{successNotice}</span>
              </div>
            )}

            {/* Error Message */}
            {errorMessage && (
              <div className="p-3 glass-card-true border-red-500/40 text-red-300 text-xs font-mono flex items-center gap-2 animate-fadeIn rounded-xl">
                <AlertCircle className="w-4 h-4 flex-shrink-0 text-red-400" />
                <span>{errorMessage}</span>
              </div>
            )}

            {/* Login Form */}
            <form onSubmit={handleLogin} className="space-y-4 text-xs font-mono">
              <div className="space-y-1">
                <label className="text-zinc-300 uppercase tracking-widest text-[10px] font-bold">LOGIN EMAIL:</label>
                <div className="relative">
                  <input
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@domain.com"
                    className="w-full glass-input-true py-3 pl-9 pr-3 rounded-xl font-sans text-white"
                    autoFocus
                  />
                  <Mail className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              <div className="space-y-1">
                <label className="text-zinc-300 uppercase tracking-widest text-[10px] font-bold">ACCESS KEY PASSWORD:</label>
                <div className="relative">
                  <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full glass-input-true py-3 pl-9 pr-3 rounded-xl font-mono text-white"
                  />
                  <Key className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
                </div>
              </div>

              <button
                type="submit"
                disabled={isLoading}
                className="w-full py-3.5 glass-button-true text-white font-mono text-xs uppercase tracking-widest font-extrabold flex items-center justify-center gap-2 transition-all shadow-xl active:scale-98 rounded-xl disabled:opacity-50 cursor-pointer"
              >
                {isLoading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" />
                    <span>AUTHENTICATING...</span>
                  </>
                ) : (
                  <>
                    <span>CONFIRM SYSTEM INGRESS</span>
                    <ArrowRight className="w-4 h-4" />
                  </>
                )}
              </button>
            </form>

            {/* Footer Copyright */}
            <div className="text-center text-[10px] font-mono text-zinc-500 tracking-widest uppercase pt-2">
              Xuan Phuc © 2026 • Executive Product OS
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
